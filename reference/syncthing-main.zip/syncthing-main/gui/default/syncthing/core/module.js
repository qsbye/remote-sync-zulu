angular.module('syncthing.core', []);
